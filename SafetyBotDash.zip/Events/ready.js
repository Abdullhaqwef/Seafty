module.exports = Client => {
    Client.user.setStatus('idle')
    Client.user.setActivity('/help | discord.gg/safetybot')
}