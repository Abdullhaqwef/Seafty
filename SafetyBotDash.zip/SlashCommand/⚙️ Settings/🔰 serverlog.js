const db = require('pro.db');
const { PermissionsBitField, EmbedBuilder } = require('boda.js');

module.exports = {
    name: 'auditlog',
    type: 1,
    description: '🛠️ Set up server logs for various events',
    options: [
        {
            name: 'log_type',
            type: 3,
            description: 'Select the type of log to set up',
            required: true,
            choices: [
                { name: '💬 Messages', value: 'messages' },
                { name: '📺 Channels', value: 'channels' },
                { name: '🎙️ Voice', value: 'voice' },
                { name: '👥 Members', value: 'members' },
                { name: '🏠 Server', value: 'guild' },
                { name: '🎭 Roles', value: 'roles' }
            ]
        },
        {
            name: 'log_channel',
            type: 7,
            description: 'Select the channel for logs',
            required: true,
            channel_types: [0]
        }
    ],

    run: async(Client, Interaction) => {
        const language = await db.get(`${Interaction.guild.id}_language`) || 'en';
        
        if(!Interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return Interaction.reply({ 
                content: language === 'ar' ? '**ليس لديك صلاحيات لاستخدام هذا الأمر**' : '**You do not have permission to use this command**', 
                ephemeral: true 
            });
        }

        const logType = Interaction.options.getString('log_type');
        const Channel = Interaction.options.getChannel('log_channel');
        let dbKey, logTypeName;

        switch(logType) {
            case 'messages': 
                logTypeName = language === 'ar' ? 'الرسائل' : 'messages';
                dbKey = `Messages_${Interaction.guildId}`;
                break;
            case 'channels':
                logTypeName = language === 'ar' ? 'القنوات' : 'channels';
                dbKey = `Channels_${Interaction.guildId}`;
                break;
            case 'voice':
                logTypeName = language === 'ar' ? 'الصوت' : 'voice';
                dbKey = `VoiceState_${Interaction.guildId}`;
                break;
            case 'members':
                logTypeName = language === 'ar' ? 'الأعضاء' : 'members';
                dbKey = `GuildMembers_${Interaction.guildId}`;
                break;
            case 'guild':
                logTypeName = language === 'ar' ? 'السيرفر' : 'server';
                dbKey = `GuildUpdates_${Interaction.guildId}`;
                break;
            case 'roles':
                logTypeName = language === 'ar' ? 'الأدوار' : 'roles';
                dbKey = `RolesUpdate_${Interaction.guildId}`;
                break;
        }

        db.set(dbKey, Channel.id);

        const embed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle(language === 'ar' ? '✅ تم تعيين سجل بنجاح' : '✅ Log Set Successfully')
            .setDescription(language === 'ar' 
                ? `تم تعيين سجل ${logTypeName} في القناة ${Channel}`
                : `${logTypeName.charAt(0).toUpperCase() + logTypeName.slice(1)} log has been set to ${Channel}`)
            .setTimestamp()
            .setFooter({ text: language === 'ar' ? 'بوت الحماية القوي' : 'Powerful Protection Bot' });

        await Interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

function createDatabase({ dbName, interaction, channel }) {
    db.set(dbName, channel.id);
    
    const language = db.get(`${interaction.guild.id}_language`) || 'en';
    const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle(language === 'ar' ? '✅ تم تعيين السجل بنجاح' : '✅ Log Set Successfully')
        .setDescription(language === 'ar' 
            ? `تم تعيين السجل في القناة ${channel}`
            : `Log has been set to ${channel}`)
        .setTimestamp()
        .setFooter({ text: language === 'ar' ? 'بوت الحماية القوي' : 'Powerful Protection Bot' });

    interaction.reply({ embeds: [embed], ephemeral: true });
}