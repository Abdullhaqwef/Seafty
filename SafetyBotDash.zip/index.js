const { Client, GatewayIntentBits, Collection, PermissionsBitField, AuditLogEvent, Partials, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('boda.js')
const db = require('pro.db');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildScheduledEvents,
        GatewayIntentBits.AutoModerationConfiguration,
        GatewayIntentBits.AutoModerationExecution,
    ],
    partials: [Partials.Channel, Partials.GuildMember, Partials.GuildScheduledEvent, Partials.Message, Partials.Reaction, Partials.ThreadMember, Partials.User]
})

const fs = require('fs')
fs.readdirSync(`${process.cwd()}/Handler/`).forEach((Handler) => {
    require(`${process.cwd()}/Handler/${Handler}`)(client)
})


client.on('messageCreate', async (message) => {
    if (['1268276619957506209', '1268276635317309530'].includes(message.channel.id)) {
        if(message.author.bot) return;
        message.react('<:saftey:1268290933049528390>')
    }
})
client.Prefix = '-'
client.commandss = new Collection()
client.commands = new Collection()

client.on('ready', () => {
    require('./server')(client)
})

client.on('interactionCreate', async (interaction) => {
    if (interaction.customId == 'ver') {
        const guildId = interaction.guild.id;
        const userId = interaction.user.id;
        const dashboardUrl = `http://localhost:3000/verify?guild=${guildId}&user=${userId}`;

        const verifyEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('Verification Process')
            .setDescription('Click the button below to complete the verification process.');

        const verifyButton = new ButtonBuilder()
            .setLabel('Verify')
            .setStyle(ButtonStyle.Link)
            .setURL(dashboardUrl);

        const row = new ActionRowBuilder()
            .addComponents(verifyButton);

        await interaction.reply({ embeds: [verifyEmbed], components: [row], ephemeral: true });
    }
})
client.on('messageCreate', async message =>{ 
    if (message.content.startsWith('-ticket')) {
    const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('boda.js');

    // Create embeds for Arabic and English
    const ticketEmbedAr = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setTitle('🎫 نظام التذاكر')
        .setDescription('مرحبًا بك في نظام الدعم الخاص بنا. إذا كنت بحاجة إلى مساعدة، يرجى الضغط على الزر أدناه لفتح تذكرة.');

    const ticketEmbedEn = new EmbedBuilder()
        .setColor(0x4CAF50)
        .setTitle('🎫 Ticket System')
        .setDescription('Welcome to our support system. If you need assistance, please click the button below to open a ticket.');

    // Create buttons for Arabic and English
    const buttonAr = new ButtonBuilder()
        .setCustomId('open_ticket_ar')
        .setLabel('فتح تذكرة')
        .setStyle(ButtonStyle.Primary);

    const buttonEn = new ButtonBuilder()
        .setCustomId('open_ticket_en')
        .setLabel('Open Ticket')
        .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder()
        .addComponents(buttonAr, buttonEn);

    // Send both embeds with the buttons
    await message.channel.send({ embeds: [ticketEmbedAr, ticketEmbedEn], components: [row] });
    }
})

// Ticket interaction handling
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    const { guild, member, customId } = interaction;
    const lang = customId.endsWith('_ar') ? 'ar' : 'en';

    if (customId.startsWith('open_ticket')) {
        // Check if user already has an open ticket
        const existingTicket = guild.channels.cache.find(channel => 
            channel.name === `ticket-${member.user.username.replace(/\./g, '')}`
        );

        if (existingTicket) {
            return interaction.reply({
                content: lang === 'ar' ? 'لديك بالفعل تذكرة مفتوحة!' : 'You already have an open ticket!',
                ephemeral: true
            });
        }

        // Create new ticket channel
        const ticketChannel = await guild.channels.create({
            name: `ticket-${member.user.username}`,
            type: 0,
            parent: '1268288039902511157', // Text channel
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: ['ViewChannel'],
                },
                {
                    id: member.id,
                    allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'],
                },
                {
                    id: lang === 'en' ? '1268287145303478303' : '1268287149418086537',
                    allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'],
                },
            ],
        });

        // Create embed for the new ticket
        const ticketEmbed = {
            color: 0x4CAF50,
            title: lang === 'ar' ? '🎫 تذكرة جديدة' : '🎫 New Ticket',
            description: lang === 'ar' 
                ? `مرحبًا ${member}! هذه هي تذكرتك. يرجى وصف مشكلتك وسيقوم أحد أعضاء الفريق بمساعدتك قريبًا.`
                : `Hello ${member}! This is your ticket. Please describe your issue and a staff member will assist you soon.`,
            footer: { text: lang === 'ar' ? 'شكرًا لصبرك' : 'Thank you for your patience' },
        };

        // Create close ticket button
        const closeButton = {
            type: 1,
            components: [{
                type: 2,
                style: 4,
                label: lang === 'ar' ? 'إغلاق التذكرة' : 'Close Ticket',
                custom_id: `close_ticket_${lang}`,
            }],
        };

        await ticketChannel.send({ embeds: [ticketEmbed], components: [closeButton] });

        return interaction.reply({
            content: lang === 'ar' 
                ? `تم إنشاء تذكرتك بنجاح! يرجى الانتقال إلى ${ticketChannel}`
                : `Your ticket has been successfully created! Please proceed to ${ticketChannel}`,
            ephemeral: true
        });
    }

    if (customId.startsWith('close_ticket')) {
        const channel = interaction.channel;
        if (!channel.name.startsWith('ticket-')) {
            return interaction.reply({
                content: lang === 'ar' ? 'هذه ليست قناة تذكرة!' : 'This is not a ticket channel!',
                ephemeral: true
            });
        }

        await interaction.reply(lang === 'ar' ? 'جارٍ إغلاق التذكرة...' : 'Closing the ticket...');

        setTimeout(() => {
            channel.delete().catch(error => console.error('Error deleting channel:', error));
        }, 5000);
    }
});

// client.on('messageCreate', async(message) => {
//     if (message.content.startsWith('-')) {
//         const { EmbedBuilder } = require('boda.js');
//         const creationDate = new Date().toISOString().split('T')[0]; // Today's date

//         const infoEmbedAr = new EmbedBuilder()
//             .setColor(0x4CAF50)
//             .setTitle('🛡️ معلومات عن بوت الأمان')
//             .setDescription('بوت الأمان هو حارس سيرفر الديسكورد الخاص بك. يوفر حماية متقدمة وإدارة فعالة لضمان بيئة آمنة ومنظمة لمجتمعك.')
//             .addFields(
//                 { name: 'تاريخ الإنشاء', value: creationDate, inline: true },
//                 { name: 'المطور', value: 'فريق الأمان', inline: true },
//                 { name: 'الإصدار', value: '1.0.0', inline: true },
//                 { name: 'الوصف', value: 'بوت الأمان هو حل شامل لحماية وإدارة سيرفرات الديسكورد. يتميز بمجموعة واسعة من الميزات الأمنية المتقدمة، بما في ذلك الحماية ضد الرسائل المزعجة والروابط الضارة وعمليات الاحتيال وهجمات الاختراق الجماعي. يوفر البوت أيضًا نظامًا متطورًا للتحذير والحظر، مع إمكانية تخصيص كاملة لإعدادات الأمان حسب احتياجات كل سيرفر. بالإضافة إلى ذلك، يتميز البوت بلوحة تحكم سهلة الاستخدام تتيح للمشرفين إدارة جميع جوانب الأمان بكفاءة وفعالية.' },
//                 { name: 'المميزات الرئيسية', value: '• حماية متطورة ضد التهديدات الأمنية\n• نظام إدارة مرن وقابل للتخصيص\n• لوحة تحكم سهلة الاستخدام\n• تحديثات مستمرة وتطوير دائم\n• دعم فني على مدار الساعة' }
//             )
//             .setThumbnail(client.user.displayAvatarURL())
//             .setFooter({ text: 'حماية متطورة لسيرفر الديسكورد الخاص بك' });

//         const infoEmbedEn = new EmbedBuilder()
//             .setColor(0x4CAF50)
//             .setTitle('🛡️ Safety Bot Information')
//             .setDescription('Safety Bot is the guardian of your Discord server. It provides advanced protection and effective management to ensure a safe and organized environment for your community.')
//             .addFields(
//                 { name: 'Creation Date', value: creationDate, inline: true },
//                 { name: 'Developer', value: 'Safety Team', inline: true },
//                 { name: 'Version', value: '1.0.0', inline: true },
//                 { name: 'Description', value: 'Safety Bot is a comprehensive solution for protecting and managing Discord servers. It features a wide range of advanced security features, including protection against spam, harmful links, scams, and raid attacks. The bot also provides an advanced warning and ban system, with full customization of security settings to suit each server\'s needs. Additionally, the bot features an easy-to-use control panel that allows administrators to efficiently manage all aspects of security.' },
//                 { name: 'Key Features', value: '• Advanced protection against security threats\n• Flexible and customizable management system\n• User-friendly control panel\n• Continuous updates and ongoing development\n• 24/7 technical support' }
//             )
//             .setThumbnail(client.user.displayAvatarURL())
//             .setFooter({ text: 'Advanced protection for your Discord server' });

//         message.channel.send({ embeds: [infoEmbedEn] });
//         message.channel.send({ embeds: [infoEmbedAr] });
//     }
//     }
// )
// Anti-link protection
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    
    const isAntiLinkEnabled = await db.get(`${message.guild.id}_antilink`);

    if (isAntiLinkEnabled === true) {
        // Check if the user is whitelisted
        const whitelistKey = `${message.guild.id}_antilink_whitelist`;
        const whitelist = await db.get(whitelistKey) || [];
        if (whitelist.includes(message.author.id)) return;

        if (message.member.permissions.has('Administrator')) return;
        const urlRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|(discord\.gg\/[^\s]+)|(discordapp\.com\/invite\/[^\s]+)|(facebook\.com\/[^\s]+)|(twitter\.com\/[^\s]+)|(instagram\.com\/[^\s]+)|(youtube\.com\/[^\s]+)|(tiktok\.com\/[^\s]+)|(discord\.gg\/\S+)/gi || 'discord.gg/';
        if (urlRegex.test(message.content)) {
            try {
                await message.delete();
                const language = await db.get(`${message.guild.id}_language`) || 'en';
                let warningMessage;
                if (language === 'ar') {
                    warningMessage = await message.channel.send(`${message.author}، إرسال الروابط غير مسموح به في هذا السيرفر.`);
                } else {
                    warningMessage = await message.channel.send(`${message.author}, sending links is not allowed in this server.`);
                }
                setTimeout(() => warningMessage.delete().catch(console.error), 5000);

                // Send log if logging is enabled
                const logChannelId = await db.get(`${message.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = message.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const logEmbed = new EmbedBuilder()
                            .setTitle('🔗 Anti-Link Detection')
                            .setColor(0xFF0000)
                            .setDescription(`A link was detected and removed.`)
                            .addFields(
                                { name: 'User', value: `${message.author.tag} (${message.author.id})`, inline: true },
                                { name: 'Channel', value: `${message.channel.name} (${message.channel.id})`, inline: true },
                                { name: 'Message Content', value: message.content.length > 1024 ? message.content.slice(0, 1021) + '...' : message.content }
                            )
                            .setTimestamp()
                            .setFooter({ text: `User ID: ${message.author.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-link system:', error);
            }
        }
    }
});

// Anti-Raid protection
client.on('guildMemberAdd', async (member) => {
    
    const isAntiRaidEnabled = await db.get(`${member.guild.id}_antiraid`);

    if (isAntiRaidEnabled === true) {
        // Check if the user is whitelisted
        const whitelistKey = `${member.guild.id}_antiraid_whitelist`;
        const whitelist = await db.get(whitelistKey) || [];
        if (whitelist.includes(member.id)) return;

        const joinedAt = member.joinedAt;
        const recentMembers = member.guild.members.cache.filter(m => m.joinedAt > joinedAt - 10000);

        if (recentMembers.size > 10) {
            try {
                await member.kick('Anti-Raid protection');

                // Send log if logging is enabled
                const logChannelId = await db.get(`${member.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = member.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const language = await db.get(`${member.guild.id}_language`) || 'en';
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '🛑 تم تفعيل حماية ضد الغارات' : '🛑 Anti-Raid Protection Triggered')
                            .setColor(0xFF0000)
                            .setDescription(language === 'ar' ? 'تم اكتشاف غارة محتملة وتم طرد مستخدم.' : 'A potential raid was detected and a user was kicked.')
                            .addFields(
                                { name: language === 'ar' ? 'المستخدم' : 'User', value: `${member.user.tag} (${member.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء' : 'Action', value: language === 'ar' ? 'تم الطرد' : 'Kicked', inline: true },
                                { name: language === 'ar' ? 'السبب' : 'Reason', value: language === 'ar' ? 'انضم أثناء غارة محتملة (أكثر من 10 انضمامات في 10 ثوانٍ)' : 'Joined during potential raid (10+ joins in 10 seconds)' }
                            )
                            .setTimestamp()
                            .setFooter({ text: `User ID: ${member.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-raid system:', error);
            }
        }
    }
});


// Anti-Scam protection
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    const isAntiScamEnabled = await db.get(`${message.guild.id}_antiscam`);

    if (isAntiScamEnabled === true) {
        // Check if the user is whitelisted
        const whitelistKey = `${message.guild.id}_antiscam_whitelist`;
        const whitelist = await db.get(whitelistKey) || [];
        if (whitelist.includes(message.author.id)) return;

        // List of common scam phrases or patterns
        const scamPatterns = [
            /free\s*nitro/i,
            /steam\s*gift/i,
            /discord\s*nitro\s*giveaway/i,
            /\b(?:https?:\/\/)?(?:discord\.(?:gg|io|me|li)|discordapp\.com\/invite)\/[a-z0-9]+\b/i,
            /claim\s*your\s*prize/i
        ];

        if (scamPatterns.some(pattern => pattern.test(message.content))) {
            try {
                await message.delete();
                await message.member.timeout(300000, 'Potential scam message detected');

                // Send log if logging is enabled
                const logChannelId = await db.get(`${message.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = message.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const language = await db.get(`${message.guild.id}_language`) || 'en';
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '🕵️ تم تفعيل الحماية ضد الاحتيال' : '🕵️ Anti-Scam Protection Triggered')
                            .setColor(0xFFFF00)
                            .setDescription(language === 'ar' ? 'تم اكتشاف رسالة احتيال محتملة وإزالتها.' : 'A potential scam message was detected and removed.')
                            .addFields(
                                { name: language === 'ar' ? 'المستخدم' : 'User', value: `${message.author.tag} (${message.author.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء' : 'Action', value: language === 'ar' ? 'تم حذف الرسالة وإيقاف المستخدم مؤقتًا لمدة 5 دقائق' : 'Message deleted and user timed out for 5 minutes', inline: true },
                                { name: language === 'ar' ? 'محتوى الرسالة' : 'Message Content', value: message.content.slice(0, 1024) }
                            )
                            .setTimestamp()
                            .setFooter({ text: `User ID: ${message.author.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-scam system:', error);
            }
        }
    }
});


// Anti-Spam System
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    const isAntiSpamEnabled = await db.get(`${message.guild.id}_antispam`);
    if (!isAntiSpamEnabled) return;
    if (isAntiSpamEnabled !== true) return;
    if (message.member.permissions.has('Administrator')) return;

    // Check if the user is whitelisted
    const whitelistKey = `${message.guild.id}_antispam_whitelist`;
    const whitelist = await db.get(whitelistKey) || [];
    if (whitelist.includes(message.author.id)) return;

    const spamThreshold = await db.get(`${message.guild.id}_antispam_limit`) || 5; // Default to 5 if not set
    const spamInterval = 5000; // Time window in milliseconds
    const timeoutDuration = 300000; // 5 minutes in milliseconds

    const userMessages = message.author.messages || new Set();
    userMessages.add(message.id);
    message.author.messages = userMessages;

    setTimeout(() => {
        userMessages.delete(message.id);
        if (userMessages.size === 0) {
            delete message.author.messages;
        }
    }, spamInterval);

    if (userMessages.size > spamThreshold) {
        try {
            const userWarnings = message.author.warnings || 0;
            const language = await db.get(`${message.guild.id}_language`) || 'en';

            if (userWarnings === 0) {
                // First offense: Warning
                message.author.warnings = 1;
                if (language === 'ar') {
                    await message.channel.send(`${message.author}، هذا تحذير. يرجى التوقف عن الإرسال المتكرر.`);
                } else {
                    await message.channel.send(`${message.author}, this is a warning. Please stop spamming.`);
                }
            } else {
                // Second offense: Timeout
                await message.member.timeout(timeoutDuration, 'Spamming detected after warning');
                await message.channel.bulkDelete([...userMessages]);
                message.author.warnings = 0; // Reset warnings after timeout

                // Send log if logging is enabled
                const logChannelId = await db.get(`${message.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = message.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '🚫 تم تفعيل الحماية ضد الرسائل المتكررة' : '🚫 Anti-Spam Protection Triggered')
                            .setColor(0xFF0000)
                            .setDescription(language === 'ar' ? 'تم اكتشاف رسائل متكررة من مستخدم. تم اتخاذ إجراء.' : 'Spam detected from a user. Action has been taken.')
                            .addFields(
                                { name: language === 'ar' ? 'المستخدم' : 'User', value: `${message.author.tag} (${message.author.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء' : 'Action', value: language === 'ar' ? 'تم حذف الرسائل وإيقاف المستخدم مؤقتًا لمدة 5 دقائق' : 'Messages deleted and user timed out for 5 minutes', inline: true },
                                { name: language === 'ar' ? 'عدد الرسائل المتكررة' : 'Spam Count', value: language === 'ar' ? `${userMessages.size} رسائل في ${spamInterval / 1000} ثوانٍ` : `${userMessages.size} messages in ${spamInterval / 1000} seconds` }
                            )
                            .setTimestamp()
                            .setFooter({ text: `User ID: ${message.author.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            }

            delete message.author.messages;
        } catch (error) {
            console.error('Error in anti-spam system:', error);
        }
    }
});


// Anti-Channel Delete Protection
client.on('channelDelete', async (channel) => {
    const isAntiChannelDeleteEnabled = await db.get(`${channel.guild.id}_antichandeldelete`);
    if (isAntiChannelDeleteEnabled === true) {
        const deleteLimit = await db.get(`${channel.guild.id}_antichanneldelete_limit`) || 1; // Default to 1 if not set
        const deletionCount = await db.get(`${channel.guild.id}_channel_deletions`) || 0;
        const language = await db.get(`${channel.guild.id}_language`) || 'en';

        if (deletionCount >= deleteLimit) {
            const auditLogs = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete, limit: 1 });
            const deletionLog = auditLogs.entries.first();

            if (!deletionLog) return;

            const { executor } = deletionLog;
            if (executor.id === client.user.id) return;
            if (channel.guild.ownerId === executor.id) return;

            // Check if the executor is whitelisted
            const whitelistKey = `${channel.guild.id}_antichanneldelete_whitelist`;
            const whitelist = await db.get(whitelistKey) || [];
            if (whitelist.includes(executor.id)) return;

            try {
                const newChannel = await channel.clone();
                await newChannel.setPosition(channel.position);

                // Get the punishment action
                const punishmentAction = await db.get(`${channel.guild.id}_punishment`) || 'removeroles';

                // Apply the punishment
                const member = await channel.guild.members.fetch(executor.id);
                switch (punishmentAction) {
                    case 'removeroles':
                        await member.roles.remove(member.roles.cache);
                        break;
                    case 'kick':
                        await member.kick('Anti-Channel Delete Protection');
                        break;
                    case 'ban':
                        await member.ban({ reason: 'Anti-Channel Delete Protection' });
                        break;
                }

                const logChannelId = await db.get(`${channel.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = channel.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '🗑️ تم تفعيل حماية حذف القنوات' : '🗑️ Anti-Channel Delete Triggered')
                            .setColor(0x800080)
                            .setDescription(language === 'ar' ? 'تم حذف قناة وتمت استعادتها. تم تطبيق العقوبة على المنفذ.' : 'A channel was deleted and has been restored. Punishment applied to the executor.')
                            .addFields(
                                { name: language === 'ar' ? 'اسم القناة' : 'Channel Name', value: channel.name, inline: true },
                                { name: language === 'ar' ? 'تم الحذف بواسطة' : 'Deleted By', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: language === 'ar' ? `تمت استعادة القناة وتطبيق ${punishmentAction} على المنفذ` : `Channel restored and ${punishmentAction} applied to executor` }
                            )
                            .setTimestamp()
                            .setFooter({ text: language === 'ar' ? `معرف القناة: ${channel.id}` : `Channel ID: ${channel.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-channel delete system:', error);
            }
        }

        // Increment the deletion count
        await db.set(`${channel.guild.id}_channel_deletions`, deletionCount + 1);

        // Reset the count after 10 minutes
        setTimeout(async () => {
            await db.set(`${channel.guild.id}_channel_deletions`, 0);
        }, 600000);
    }
});

// Anti-Channel Create Protection
client.on('channelCreate', async (channel) => {
    const isAntiChannelCreateEnabled = await db.get(`${channel.guild.id}_antichanelcreate`);
    if (isAntiChannelCreateEnabled === true) {
        const createLimit = await db.get(`${channel.guild.id}_antichannelcreate_limit`) || 1; // Default to 1 if not set
        const creationCount = await db.get(`${channel.guild.id}_channel_creations`) || 0;
        const language = await db.get(`${channel.guild.id}_language`) || 'en';

        if (creationCount >= createLimit) {
            const auditLogs = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelCreate, limit: 1 });
            const creationLog = auditLogs.entries.first();

            if (!creationLog) return;

            const { executor } = creationLog;
            if (executor.id === client.user.id) return;
            if (channel.guild.ownerId === executor.id) return;

            // Check if the executor is whitelisted
            const whitelistKey = `${channel.guild.id}_antichannelcreate_whitelist`;
            const whitelist = await db.get(whitelistKey) || [];
            if (whitelist.includes(executor.id)) return;

            try {
                await channel.delete();

                // Get the punishment action
                const punishmentAction = await db.get(`${channel.guild.id}_punishment`) || 'removeroles';

                // Apply the punishment
                const member = await channel.guild.members.fetch(executor.id);
                switch (punishmentAction) {
                    case 'removeroles':
                        await member.roles.remove(member.roles.cache);
                        break;
                    case 'kick':
                        await member.kick('Anti-Channel Create Protection');
                        break;
                    case 'ban':
                        await member.ban({ reason: 'Anti-Channel Create Protection' });
                        break;
                }

                const logChannelId = await db.get(`${channel.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = channel.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '➕ تم تفعيل حماية إنشاء القنوات' : '➕ Anti-Channel Create Triggered')
                            .setColor(0xFFA500)
                            .setDescription(language === 'ar' ? 'تم اكتشاف إنشاء قناة غير مصرح به وتم إلغاؤه. تم تطبيق العقوبة على المنفذ.' : 'An unauthorized channel creation was detected and reversed. Punishment applied to the executor.')
                            .addFields(
                                { name: language === 'ar' ? 'اسم القناة' : 'Channel Name', value: channel.name, inline: true },
                                { name: language === 'ar' ? 'تم الإنشاء بواسطة' : 'Created By', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: language === 'ar' ? `تم حذف القناة وتطبيق ${punishmentAction} على المنفذ` : `Channel deleted and ${punishmentAction} applied to executor` }
                            )
                            .setTimestamp()
                            .setFooter({ text: language === 'ar' ? `معرف القناة: ${channel.id}` : `Channel ID: ${channel.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-channel create system:', error);
            }
        }

        // Increment the creation count
        await db.set(`${channel.guild.id}_channel_creations`, creationCount + 1);

        // Reset the count after 10 minutes
        setTimeout(async () => {
            await db.set(`${channel.guild.id}_channel_creations`, 0);
        }, 600000);
    }
});

// Anti-Channel Edit Protection
client.on('channelUpdate', async (oldChannel, newChannel) => {
    const isAntiChannelEditEnabled = await db.get(`${newChannel.guild.id}_antichanneledit`);
    if (isAntiChannelEditEnabled === true) {
        const editLimit = await db.get(`${newChannel.guild.id}_antichanneledit_limit`) || 1; // Default to 1 if not set
        const editCount = await db.get(`${newChannel.guild.id}_channel_edits`) || 0;
        const language = await db.get(`${newChannel.guild.id}_language`) || 'en';

        if (editCount >= editLimit) {
            const auditLogs = await newChannel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelUpdate, limit: 1 });
            const updateLog = auditLogs.entries.first();

            if (!updateLog) return;

            const { executor } = updateLog;
            if (executor.id === client.user.id) return;
            if (newChannel.guild.ownerId === executor.id) return;

            // Check whitelist
            const whitelist = await db.get(`${newChannel.guild.id}_whitelist`) || [];
            if (whitelist.includes(executor.id)) return;

            try {
                await newChannel.edit({
                    name: oldChannel.name,
                    topic: oldChannel.topic,
                    nsfw: oldChannel.nsfw,
                    bitrate: oldChannel.bitrate,
                    userLimit: oldChannel.userLimit,
                    rateLimitPerUser: oldChannel.rateLimitPerUser,
                    permissions: oldChannel.permissionOverwrites.cache
                });

                // Get the punishment action
                const punishmentAction = await db.get(`${newChannel.guild.id}_punishment`) || 'removeroles';

                // Apply the punishment
                const member = await newChannel.guild.members.fetch(executor.id);
                switch (punishmentAction) {
                    case 'removeroles':
                        await member.roles.remove(member.roles.cache);
                        break;
                    case 'kick':
                        await member.kick('Anti-Channel Edit Protection');
                        break;
                    case 'ban':
                        await member.ban({ reason: 'Anti-Channel Edit Protection' });
                        break;
                }

                const logChannelId = await db.get(`${newChannel.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = newChannel.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '✏️ تم تفعيل حماية تعديل القنوات' : '✏️ Anti-Channel Edit Triggered')
                            .setColor(0x008080)
                            .setDescription(language === 'ar' ? 'تم اكتشاف تعديل غير مصرح به للقناة وتم إلغاؤه. تم تطبيق العقوبة على المنفذ.' : 'An unauthorized channel edit was detected and reversed. Punishment applied to the executor.')
                            .addFields(
                                { name: language === 'ar' ? 'اسم القناة' : 'Channel Name', value: newChannel.name, inline: true },
                                { name: language === 'ar' ? 'تم التعديل بواسطة' : 'Edited By', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: language === 'ar' ? `تم إلغاء تعديل القناة وتطبيق ${punishmentAction} على المنفذ` : `Channel edit reversed and ${punishmentAction} applied to executor` }
                            )
                            .setTimestamp()
                            .setFooter({ text: language === 'ar' ? `معرف القناة: ${newChannel.id}` : `Channel ID: ${newChannel.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-channel edit system:', error);
            }
        }

        // Increment the edit count
        await db.set(`${newChannel.guild.id}_channel_edits`, editCount + 1);

        // Reset the count after 10 minutes
        setTimeout(async () => {
            await db.set(`${newChannel.guild.id}_channel_edits`, 0);
        }, 600000);
    }
});

// Anti-Role Create Protection
client.on('roleCreate', async (role) => {
    const isAntiRoleCreateEnabled = await db.get(`${role.guild.id}_antirolecreate`);
    if (isAntiRoleCreateEnabled === true) {
        const createLimit = await db.get(`${role.guild.id}_antirolecreate_limit`) || 1; // Default to 1 if not set
        const creationCount = await db.get(`${role.guild.id}_role_creations`) || 0;

        if (creationCount >= createLimit) {
            const auditLogs = await role.guild.fetchAuditLogs({ type: AuditLogEvent.RoleCreate, limit: 1 });
            const creationLog = auditLogs.entries.first();

            if (!creationLog) return;

            const { executor } = creationLog;
            if (executor.id === client.user.id) return;
            if (role.guild.ownerId === executor.id) return;

            // Check whitelist
            const whitelist = await db.get(`${role.guild.id}_whitelist`) || [];
            if (whitelist.includes(executor.id)) return;

            try {
                await role.delete();

                // Get the punishment action
                const punishmentAction = await db.get(`${role.guild.id}_punishment`) || 'removeroles';

                // Apply the punishment
                const member = await role.guild.members.fetch(executor.id);
                switch (punishmentAction) {
                    case 'removeroles':
                        await member.roles.remove(member.roles.cache);
                        break;
                    case 'kick':
                        await member.kick('Anti-Role Create Protection');
                        break;
                    case 'ban':
                        await member.ban({ reason: 'Anti-Role Create Protection' });
                        break;
                }

                const logChannelId = await db.get(`${role.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = role.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const language = await db.get(`${role.guild.id}_language`) || 'en';
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '🏷️ تم تفعيل حماية إنشاء الرتب' : '🏷️ Anti-Role Create Triggered')
                            .setColor(0x1E90FF)
                            .setDescription(language === 'ar' ? 'تم اكتشاف إنشاء رتبة غير مصرح به وتم إلغاؤه. تم تطبيق العقوبة على المنفذ.' : 'An unauthorized role creation was detected and reversed. Punishment applied to the executor.')
                            .addFields(
                                { name: language === 'ar' ? 'اسم الرتبة' : 'Role Name', value: role.name, inline: true },
                                { name: language === 'ar' ? 'تم الإنشاء بواسطة' : 'Created By', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: language === 'ar' ? `تم حذف الرتبة وتطبيق ${punishmentAction} على المنفذ` : `Role deleted and ${punishmentAction} applied to executor` }
                            )
                            .setTimestamp()
                            .setFooter({ text: language === 'ar' ? `معرف الرتبة: ${role.id}` : `Role ID: ${role.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-role create system:', error);
            }
        }

        // Increment the creation count
        await db.set(`${role.guild.id}_role_creations`, creationCount + 1);

        // Reset the count after 10 minutes
        setTimeout(async () => {
            await db.set(`${role.guild.id}_role_creations`, 0);
        }, 600000);
    }
});

// Anti-Role Delete Protection
client.on('roleDelete', async (role) => {
    const isAntiRoleDeleteEnabled = await db.get(`${role.guild.id}_antiroledelete`);
    if (isAntiRoleDeleteEnabled === true) {
        const deleteLimit = await db.get(`${role.guild.id}_antiroledelete_limit`) || 1; // Default to 1 if not set
        const deletionCount = await db.get(`${role.guild.id}_role_deletions`) || 0;

        if (deletionCount >= deleteLimit) {
            const auditLogs = await role.guild.fetchAuditLogs({ type: AuditLogEvent.RoleDelete, limit: 1 });
            const deletionLog = auditLogs.entries.first();

            if (!deletionLog) return;

            const { executor } = deletionLog;
            if (executor.id === client.user.id) return;
            if (role.guild.ownerId === executor.id) return;

            // Check whitelist
            const whitelist = await db.get(`${role.guild.id}_whitelist`) || [];
            if (whitelist.includes(executor.id)) return;

            try {
                const newRole = await role.guild.roles.create({
                    name: role.name,
                    color: role.color,
                    hoist: role.hoist,
                    permissions: role.permissions,
                    position: role.position,
                    mentionable: role.mentionable
                });

                // Get the punishment action
                const punishmentAction = await db.get(`${role.guild.id}_punishment`) || 'removeroles';

                // Apply the punishment
                const member = await role.guild.members.fetch(executor.id);
                switch (punishmentAction) {
                    case 'removeroles':
                        await member.roles.remove(member.roles.cache);
                        break;
                    case 'kick':
                        await member.kick('Anti-Role Delete Protection');
                        break;
                    case 'ban':
                        await member.ban({ reason: 'Anti-Role Delete Protection' });
                        break;
                }

                const logChannelId = await db.get(`${role.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = role.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const language = await db.get(`${role.guild.id}_language`) || 'en';
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '🗑️ تم تفعيل حماية حذف الرتب' : '🗑️ Anti-Role Delete Triggered')
                            .setColor(0xDC143C)
                            .setDescription(language === 'ar' ? 'تم حذف رتبة وتمت استعادتها. تم إزالة جميع الرتب من المنفذ.' : 'A role was deleted and has been restored. All roles removed from the executor.')
                            .addFields(
                                { name: language === 'ar' ? 'اسم الرتبة' : 'Role Name', value: role.name, inline: true },
                                { name: language === 'ar' ? 'تم الحذف بواسطة' : 'Deleted By', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: language === 'ar' ? 'تمت استعادة الرتبة وإزالة جميع الرتب من المنفذ' : 'Role restored and all roles removed from executor' }
                            )
                            .setTimestamp()
                            .setFooter({ text: language === 'ar' ? `معرف الرتبة: ${newRole.id}` : `Role ID: ${newRole.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-role delete system:', error);
            }
        }

        // Increment the deletion count
        await db.set(`${role.guild.id}_role_deletions`, deletionCount + 1);

        // Reset the count after 10 minutes
        setTimeout(async () => {
            await db.set(`${role.guild.id}_role_deletions`, 0);
        }, 600000);
    }
});

client.on('roleUpdate', async (oldRole, newRole) => {
    const isAntiRoleEditEnabled = await db.get(`${newRole.guild.id}_antiroleedit`);
    if (isAntiRoleEditEnabled === true) {
        const editLimit = await db.get(`${newRole.guild.id}_antiroleedit_limit`) || 3; // Default to 3 if not set
        const editCount = await db.get(`${newRole.guild.id}_role_edits`) || 0;

        if (editCount >= editLimit) {
            const auditLogs = await newRole.guild.fetchAuditLogs({ type: AuditLogEvent.RoleUpdate, limit: 1 });
            const updateLog = auditLogs.entries.first();

            if (!updateLog) return;

            const { executor } = updateLog;
            if (executor.id === client.user.id) return;
            if (newRole.guild.ownerId === executor.id) return;

            // Check whitelist
            const whitelist = await db.get(`${newRole.guild.id}_whitelist`) || [];
            if (whitelist.includes(executor.id)) return;

            try {
                await newRole.edit({
                    name: oldRole.name,
                    color: oldRole.color,
                    hoist: oldRole.hoist,
                    permissions: oldRole.permissions,
                    mentionable: oldRole.mentionable
                });

                // تحديد العقوبة
                const punishmentAction = await db.get(`${newRole.guild.id}_punishment`) || 'removeroles';

                // تطبيق العقوبة
                const member = await newRole.guild.members.fetch(executor.id);
                switch (punishmentAction) {
                    case 'removeroles':
                        await member.roles.remove(member.roles.cache);
                        break;
                    case 'kick':
                        await member.kick('Anti-Role Edit Protection');
                        break;
                    case 'ban':
                        await member.ban({ reason: 'Anti-Role Edit Protection' });
                        break;
                }

                const logChannelId = await db.get(`${newRole.guild.id}_logchannel`);
                if (logChannelId) {
                    const logChannel = newRole.guild.channels.cache.get(logChannelId);
                    if (logChannel) {
                        const { EmbedBuilder } = require('boda.js');
                        const language = await db.get(`${newRole.guild.id}_language`) || 'en';
                        const logEmbed = new EmbedBuilder()
                            .setTitle(language === 'ar' ? '✏️ تم تفعيل حماية تعديل الرتب' : '✏️ Anti-Role Edit Triggered')
                            .setColor(0x32CD32)
                            .setDescription(language === 'ar' ? 'تم اكتشاف تعديل غير مصرح به للرتبة وتم إلغاؤه. تم تطبيق العقوبة.' : 'An unauthorized role edit was detected and reversed. Punishment applied.')
                            .addFields(
                                { name: language === 'ar' ? 'اسم الرتبة' : 'Role Name', value: newRole.name, inline: true },
                                { name: language === 'ar' ? 'تم التعديل بواسطة' : 'Edited By', value: `${executor.tag} (${executor.id})`, inline: true },
                                { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: language === 'ar' ? `تم إلغاء تعديل الرتبة وتطبيق ${punishmentAction}` : `Role edit reversed and ${punishmentAction} applied` }
                            )
                            .setTimestamp()
                            .setFooter({ text: language === 'ar' ? `معرف الرتبة: ${newRole.id}` : `Role ID: ${newRole.id}` });

                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (error) {
                console.error('Error in anti-role edit system:', error);
            }
        }
        await db.set(`${newRole.guild.id}_role_edits`, editCount + 1);
        setTimeout(async () => {
            await db.set(`${newRole.guild.id}_role_edits`, 0);
        }, 600000);
    }
});

client.on('guildMemberUpdate', async (oldMember, newMember) => {
    const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
    if (addedRoles.size === 0) return; // No new roles added
    const antiAdminGrantEnabled = await db.get(`${newMember.guild.id}_antiadmingrant`);
    if (!antiAdminGrantEnabled) return;
    const adminRole = addedRoles.find(role => role.permissions.has(PermissionsBitField.Flags.Administrator));
    if (!adminRole) return;
    if (newMember.roles.cache.has(adminRole.id)) {
        console.log('Anti-Admin Grant triggered:', antiAdminGrantEnabled);
        const auditLogs = await newMember.guild.fetchAuditLogs({
            limit: 1,
            type: AuditLogEvent.MemberRoleUpdate,
        });
        const log = auditLogs.entries.first();
        if (!log) return;

        const { executor } = log;
        if (executor.id === client.user.id || executor.id === newMember.guild.ownerId) return;

        const executorMember = await newMember.guild.members.fetch(executor.id);
        console.log(executorMember)
        if (!executorMember.permissions.has(PermissionsBitField.Flags.Administrator)) return;

        // Check whitelist
        const whitelist = await db.get(`${newMember.guild.id}_antiadmingrant_whitelist`) || [];
        if (whitelist.includes(executor.id)) return;

        try {
            await newMember.roles.remove(addedRoles);

            const punishmentAction = await db.get(`${newMember.guild.id}_punishment`) || 'removeroles';
            const member = await newMember.guild.members.fetch(executor.id);

            switch (punishmentAction) {
                case 'removeroles':
                    await member.roles.remove(member.roles.cache);
                    break;
                case 'kick':
                    await member.kick('Unauthorized Admin Role Grant');
                    break;
                case 'ban':
                    await member.ban({ reason: 'Unauthorized Admin Role Grant' });
                    break;
            }

            const logChannelId = await db.get(`${newMember.guild.id}_logchannel`);
            if (logChannelId) {
                const logChannel = newMember.guild.channels.cache.get(logChannelId);
                if (logChannel) {
                    const { EmbedBuilder } = require('boda.js');
                    const language = await db.get(`${newMember.guild.id}_language`) || 'en';
                    const logEmbed = new EmbedBuilder()
                        .setTitle(language === 'ar' ? '👑 تم اكتشاف منح غير مصرح به لرتبة الإدارة' : '👑 Unauthorized Admin Role Grant Detected')
                        .setColor(0xFF0000)
                        .setDescription(language === 'ar' ? 'حاول أحد المشرفين منح رتبة إدارية لمستخدم آخر. تم منع هذا الإجراء.' : 'An administrator attempted to grant admin role to another user. This action was prevented.')
                        .addFields(
                            { name: language === 'ar' ? 'المستخدم المستهدف' : 'Target User', value: `${newMember.user.tag} (${newMember.id})`, inline: true },
                            { name: language === 'ar' ? 'تم المنح بواسطة' : 'Granted By', value: `${executor.tag} (${executor.id})`, inline: true },
                            { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: language === 'ar' ? `تمت إزالة الرتبة الإدارية وتطبيق ${punishmentAction} على المانح` : `Admin role removed and ${punishmentAction} applied to the granter` }
                        )
                        .setTimestamp();

                    logChannel.send({ embeds: [logEmbed] });
                }
            }
        } catch (error) {
            console.error('Error in preventing unauthorized admin role grant:', error);
        }
    }
});



// Anti-Kick Protection
client.on('guildMemberRemove', async (member) => {
    const antiKick = await db.get(`${member.guild.id}_antikick`);
    if (!antiKick) return;

    const auditLogs = await member.guild.fetchAuditLogs({ type: 20, limit: 1 });
    const kickLog = auditLogs.entries.first();

    if (!kickLog) return;

    const { executor } = kickLog;
    if (executor.id === client.user.id) return;

    const executorMember = await member.guild.members.fetch(executor.id);
    if (executorMember.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    // Check whitelist
    const whitelist = await db.get(`${member.guild.id}_antikick_whitelist`) || [];
    if (whitelist.includes(executor.id)) return;

    const kickLimit = await db.get(`${member.guild.id}_antikick_limit`) || 3;
    const kickCount = await db.get(`${member.guild.id}_${executor.id}_kickcount`) || 0;

    await db.set(`${member.guild.id}_${executor.id}_kickcount`, kickCount + 1);

    if (kickCount + 1 >= kickLimit) {
        const punishmentAction = await db.get(`${member.guild.id}_punishment`) || 'removeroles';

        switch (punishmentAction) {
            case 'removeroles':
                await executorMember.roles.remove(executorMember.roles.cache);
                break;
            case 'kick':
                await executorMember.kick('Exceeded kick limit');
                break;
            case 'ban':
                await executorMember.ban({ reason: 'Exceeded kick limit' });
                break;
        }

        await db.delete(`${member.guild.id}_${executor.id}_kickcount`);

        const logChannelId = await db.get(`${member.guild.id}_logchannel`);
        if (logChannelId) {
            const logChannel = member.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const language = await db.get(`${member.guild.id}_language`) || 'en';
                const logEmbed = new EmbedBuilder()
                    .setTitle(language === 'ar' ? '👢 تم تفعيل حماية ضد الطرد' : '👢 Anti-Kick Protection Triggered')
                    .setColor(0xFF0000)
                    .setDescription(language === 'ar' ? 'تجاوز أحد المستخدمين الحد المسموح به للطرد. تم تطبيق العقوبة.' : 'A user has exceeded the kick limit. Punishment has been applied.')
                    .addFields(
                        { name: language === 'ar' ? 'المنفذ' : 'Executor', value: `${executor.tag} (${executor.id})`, inline: true },
                        { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: punishmentAction, inline: true },
                        { name: language === 'ar' ? 'حد الطرد' : 'Kick Limit', value: kickLimit.toString(), inline: true }
                    )
                    .setTimestamp();

                logChannel.send({ embeds: [logEmbed] });
            }
        }
    }
});

// Anti-Ban Protection
client.on('guildBanAdd', async (ban) => {
    const antiBan = await db.get(`${ban.guild.id}_antiban`);
    if (!antiBan) return;

    const auditLogs = await ban.guild.fetchAuditLogs({ type: 22, limit: 1 });
    const banLog = auditLogs.entries.first();

    if (!banLog) return;

    const { executor } = banLog;
    if (executor.id === client.user.id) return;

    const executorMember = await ban.guild.members.fetch(executor.id);
    if (executorMember.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    // Check whitelist
    const whitelist = await db.get(`${ban.guild.id}_antiban_whitelist`) || [];
    if (whitelist.includes(executor.id)) return;

    const banLimit = await db.get(`${ban.guild.id}_antiban_limit`) || 3;
    const banCount = await db.get(`${ban.guild.id}_${executor.id}_bancount`) || 0;

    await db.set(`${ban.guild.id}_${executor.id}_bancount`, banCount + 1);

    if (banCount + 1 >= banLimit) {
        const punishmentAction = await db.get(`${ban.guild.id}_punishment`) || 'removeroles';

        switch (punishmentAction) {
            case 'removeroles':
                await executorMember.roles.remove(executorMember.roles.cache);
                break;
            case 'kick':
                await executorMember.kick('Exceeded ban limit');
                break;
            case 'ban':
                await executorMember.ban({ reason: 'Exceeded ban limit' });
                break;
        }

        await db.delete(`${ban.guild.id}_${executor.id}_bancount`);

        const logChannelId = await db.get(`${ban.guild.id}_logchannel`);
        if (logChannelId) {
            const logChannel = ban.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const language = await db.get(`${ban.guild.id}_language`) || 'en';
                const logEmbed = new EmbedBuilder()
                    .setTitle(language === 'ar' ? '🔨 تم تفعيل حماية ضد الحظر' : '🔨 Anti-Ban Protection Triggered')
                    .setColor(0xFF0000)
                    .setDescription(language === 'ar' ? 'تجاوز أحد المستخدمين الحد المسموح به للحظر. تم تطبيق العقوبة.' : 'A user has exceeded the ban limit. Punishment has been applied.')
                    .addFields(
                        { name: language === 'ar' ? 'المنفذ' : 'Executor', value: `${executor.tag} (${executor.id})`, inline: true },
                        { name: language === 'ar' ? 'الإجراء المتخذ' : 'Action Taken', value: punishmentAction, inline: true },
                        { name: language === 'ar' ? 'حد الحظر' : 'Ban Limit', value: banLimit.toString(), inline: true }
                    )
                    .setTimestamp();

                logChannel.send({ embeds: [logEmbed] });
            }
        }
    }
});

client.login(require('./Config.json').Token)